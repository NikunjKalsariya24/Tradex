import 'package:flutter/material.dart';
import 'package:screen_f/test_app.dart';

void main()
{
  runApp(const TestApp());
}

