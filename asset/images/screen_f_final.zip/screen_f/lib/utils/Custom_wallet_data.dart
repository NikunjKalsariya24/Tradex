class CustomWallet {
  String? imageDAta;
  String? tranJecTioN;
  String? tranJecTioNTime;
  String? coinPrice;
  String? differance;

  CustomWallet(
      {this.imageDAta,
      this.tranJecTioN,
      this.tranJecTioNTime,
      this.coinPrice,
      this.differance});
}
