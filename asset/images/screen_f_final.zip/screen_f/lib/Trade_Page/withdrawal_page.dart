import 'package:flutter/material.dart';
import 'package:screen_f/utils/app_assets.dart';
import 'package:screen_f/utils/app_colors.dart';

class WithdrawalPage extends StatelessWidget {
  const WithdrawalPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.colorBlackColor,
      body: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
          Image.asset(ImageAssets.withdrawalImage),
          Image.asset(ImageAssets.headphone),


        ],)

      ]),
    );
  }
}
