class CustomTradeXSuggestion {
  String? tradeImage;
  String? tradeName;
  String? tradeFullName;
  String? tradeDescription;
  String? tradePrice;

  CustomTradeXSuggestion(
      {this.tradeDescription,
      this.tradeImage,
      this.tradeName,
      this.tradePrice,this.tradeFullName});
}
