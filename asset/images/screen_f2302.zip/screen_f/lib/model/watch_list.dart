class WatchList {
  String? coinFName;
  String? coinName;
  String? coinPrice;
  String? coinBitCoinPrice;
  String? coinDifferance;

  WatchList(
      {this.coinName,
      this.coinPrice,
      this.coinBitCoinPrice,
      this.coinDifferance,
      this.coinFName});
}
