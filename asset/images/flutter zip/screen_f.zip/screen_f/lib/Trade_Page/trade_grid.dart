import 'package:flutter/material.dart';

class TradeGridScreen extends StatefulWidget {
  const TradeGridScreen({Key? key}) : super(key: key);

  @override
  State<TradeGridScreen> createState() => _TradeGridScreenState();
}

class _TradeGridScreenState extends State<TradeGridScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("Grid Screen",style: TextStyle(fontSize: 60),)),
    );
  }
}

