import 'package:flutter/material.dart';
import 'package:screen_f/Trade_Page/profile.dart';
import 'package:screen_f/Trade_Page/tab_bar.dart';
import 'package:screen_f/Trade_Page/trade_coin.dart';
import 'package:screen_f/Trade_Page/trade_watchlist.dart';
import 'package:screen_f/utils/app_assets.dart';
import 'package:screen_f/utils/app_colors.dart';
import 'package:screen_f/utils/app_string.dart';
import 'package:screen_f/utils/custom_text.dart';
import 'package:sizer/sizer.dart';

class TradeHomePage extends StatefulWidget {
  const TradeHomePage({Key? key}) : super(key: key);

  @override
  State<TradeHomePage> createState() => _TradeHomePageState();
}

class _TradeHomePageState extends State<TradeHomePage>
    with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    TabController tabControllerHome = TabController(length: 3, vsync: this);
    return Scaffold(
      backgroundColor: Appcolor.colorBlackColor,
      body: NestedScrollView(
          physics: const NeverScrollableScrollPhysics(),
          headerSliverBuilder: (context, bool innerBoxIsScrolled) {
            return <Widget>[
              SliverAppBar(
                // collapsedHeight: 15.h,
                // expandedHeight: 15.h,
                pinned: true,
                automaticallyImplyLeading: false,
                backgroundColor: Appcolor.colorBlackColor,
                expandedHeight: 30.h,

                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    height: 30.h,
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 4.h),
                    child: Image.asset(ImageAssets.tradeHomeBgImagePath),
                  ),
                ),

                actions: [
                  Widget_tradeXAppBar(),
                ],

                // flexibleSpace: Profile(),

                bottom: PreferredSize(
                    preferredSize: Size.fromHeight(6.h),
                    child: TabBar(
                        controller: tabControllerHome,
                        isScrollable: false,
                        indicatorColor: Colors.yellow,
                        indicatorSize: TabBarIndicatorSize.label,
                        padding: EdgeInsets.only(right: 5.w),
                        indicatorWeight: 2.0,
                        indicatorPadding: EdgeInsets.symmetric(vertical: 1.5.h),
                        // indicator: MaterialIndicator(
                        // horizontalPadding: 8.w,
                        // bottomLeftRadius:9.w ,
                        // bottomRightRadius:9.w  ,
                        // topLeftRadius: 9.w ,
                        // topRightRadius: 9.w ,
                        // strokeWidth: 10,
                        // tabPosition: TabPosition.bottom,
                        // color: Colors.yellow,
                        // paintingStyle: PaintingStyle.fill,),

                        tabs: [
                          CustomTabBar(
                            name: AppString.appCoin,
                            fontSize: 12.sp,
                          ),
                          CustomTabBar(
                            name: AppString.appWatchList,
                            fontSize: 12.sp,
                          ),
                          CustomTabBar(
                            name: AppString.appNewest,
                            fontSize: 12.sp,
                          ),
                        ],
                    ),

                ),
              ),
            ];
          },
          body: TabBarView(controller: tabControllerHome, children: [
            TradeCoin(controller: tabControllerHome),
            TradeWatchList(controller: tabControllerHome),
            Container(),
          ])),
    );
  }

  Widget_tradeXAppBar() {
    return Expanded(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            alignment: Alignment.topLeft,
            height: 8.h,
            margin: EdgeInsets.only(left: 1.w),
            child: CustomText(
              name: AppString.appTrad,
              fontFamily: AppString.fontFamily,
              fontSize: 30.sp,
              color: Appcolor.colorWhiteText,
            ),
          ),
          const Spacer(),

          Container(
            margin: EdgeInsets.only(
              left: 30.w,
            ),
            child:
                Icon(Icons.search, color: Appcolor.colorWhiteText, size: 8.w),
          ),

          Icon(Icons.person, color: Appcolor.colorWhiteText, size: 8.w)
        ],
      ),
    );
  }
}
