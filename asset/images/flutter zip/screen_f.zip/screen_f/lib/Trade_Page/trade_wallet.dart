import 'package:flutter/material.dart';
import 'package:screen_f/utils/app_assets.dart';
import 'package:screen_f/utils/app_colors.dart';
import 'package:screen_f/utils/app_string.dart';
import 'package:screen_f/utils/custom_text.dart';
import 'package:sizer/sizer.dart';

class TradeWalletScreen extends StatefulWidget {
  const TradeWalletScreen({Key? key}) : super(key: key);

  @override
  State<TradeWalletScreen> createState() => _TradeWalletScreenState();
}

class _TradeWalletScreenState extends State<TradeWalletScreen> {
  @override
  Widget build(BuildContext context) {
    return CustomText(name: "Wallet Page",);


      Scaffold(
      backgroundColor: Appcolor.colorBlackColor,
      body: Column(
        children: [
          Container(
              padding: EdgeInsets.only(top: 8.h),
              child: Center(
                  child: CustomText(
                      name: AppString.totalBalance,
                      fontSize: 12.sp,
                      color: Appcolor.colorWhiteText))),
          Container(
              padding: EdgeInsets.only(top: 1.h),
              child: Center(
                  child: CustomText(
                      name: AppString.btcBalance,
                      fontSize: 30.sp,
                      color: Appcolor.colorWhiteText))),
          Container(
              padding: EdgeInsets.only(top: 1.h),
              child: Center(
                  child: CustomText(
                      name: AppString.buyBtc,
                      fontSize: 18.sp,
                      color: Appcolor.colorWhiteText))),
          Container(
              padding: EdgeInsets.only(top: 1.h),
              child: Center(
                  child: CustomText(
                      name: AppString.btcWelcomeNotes,
                      fontSize: 10.sp,
                      color: Appcolor.colorYellowFull.withOpacity(0.80)))),
          Padding(
            padding: EdgeInsets.only(top: 3.h),
            child: Container(
              height: 6.h,
              width: 40.w,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.w),
                color: Appcolor.colorBlackGradiant,
              ),
              child: Row(children: [
                Padding(
                  padding: EdgeInsets.only(left: 3.w),
                  child: Icon(
                    Icons.search,
                    color: Appcolor.colorWhiteText.withOpacity(0.80),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 3.w),
                  child: CustomText(
                      name: AppString.btcSearch,
                      color: Appcolor.colorWhiteText.withOpacity(0.80),
                      fontSize: 12.sp),
                )
              ]),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 3.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                    height: 6.h,
                    width: 40.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.w),
                        color: Appcolor.colorBlackGradiant),
                child: Row(children: [
                  Padding(
                    padding: EdgeInsets.only(left: 6.w),
                    child: Image.asset(ImageAssets.arrowDownLeft),
                  ),
                  CustomText(name: AppString.btcDeposit,color: Appcolor.colorWhiteText,fontSize: 16.sp,)
                  
                ],)),
                Container(
                    height: 6.h,
                    width: 40.w,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.w),
                        color: Appcolor.colorToggleColor),
                    child: Row(children: [
                      Padding(
                        padding: EdgeInsets.only(left: 10.w),
                        child: Image.asset(ImageAssets.arrowUpRight),
                      ),
                      CustomText(name: AppString.btcSend,color: Appcolor.colorBlackColor,fontSize: 16.sp,)

                    ],)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
