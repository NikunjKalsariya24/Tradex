import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:screen_f/controller/trade_coin_controller.dart';
import 'package:screen_f/utils/app_colors.dart';
import 'package:screen_f/utils/app_string.dart';
import 'package:screen_f/utils/custom_text.dart';
import 'package:sizer/sizer.dart';

class TradeWatchList extends StatelessWidget {
  final TabController controller;

  TradeWatchList({Key? key, required this.controller}) : super(key: key);
  final TradeCoinController tradeCoinController =
      Get.put(TradeCoinController());

  @override
  Widget build(BuildContext context) {
    // var size = MediaQuery.of(context).size;
    // final double itemWidth = size.width / 2;
    // final double itemHeight = (size.height - kToolbarHeight - 24) / 2;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 1.w),
      child: Column(
        children: [
          Column(
            children: [
              SizedBox(
                height: 50.h,
                width: double.infinity,
                child: GridView.builder(
                  itemCount: tradeCoinController.watchListAll.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, childAspectRatio: 1.4),
                  itemBuilder: (context, index) {
                    return Container(
                      height: 10.h,
                      width: 40.w,
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Appcolor.colorBlackBottomSS,
                        borderRadius: BorderRadius.circular(8.w),
                      ),
                      child: Column(children: [
                        Container(
                          alignment: Alignment.topLeft,
                          margin: EdgeInsets.only(left: 5.w, top: 3.w),
                          child: CustomText(
                              name:
                                  tradeCoinController.watchListAll[index].coinFName,
                              color: Appcolor.colorWhiteText,
                              fontSize: 16.sp),
                        ),
                        Container(
                            alignment: Alignment.topLeft,
                            margin: EdgeInsets.only(left: 5.w),
                            child: CustomText(
                              name:
                                  tradeCoinController.watchListAll[index].coinName,
                              color: Appcolor.colorWhiteText,
                              fontSize: 10.sp,
                            )),
                        Spacer(),
                        Container(
                            alignment: Alignment.topLeft,
                            margin: EdgeInsets.only(left: 5.w),
                            child: CustomText(
                              name:
                              tradeCoinController.watchListAll[index].coinPrice,
                              color: Appcolor.colorWhiteText,
                              fontSize: 10.sp,
                            )),

                        Container(
                            alignment: Alignment.topLeft,
                            margin: EdgeInsets.only(left: 5.w),
                            child: CustomText(
                              name:
                              tradeCoinController.watchListAll[index].coinBitCoinPrice,
                              color: Appcolor.colorWhiteText,
                              fontSize: 10.sp,
                            ),),
                        Spacer(),
                        Container(
                          alignment: Alignment.topLeft,
                          margin: EdgeInsets.only(left: 8.w),
                          child: CustomText(
                            name:
                            tradeCoinController.watchListAll[index].coinDifferance,
                            color: Appcolor.colorGrid,
                            fontSize: 10.sp,
                          ),),







                      ]

                      ),
                    );
                  },
                ),
              ),
              // Spacer(),
              SizedBox(height: 1.h,),
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                        height: 5.h,
                        width: 40.w,
                        margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.w),
                            color: Appcolor.colorBlackBottomSS),
                        child: Center(
                            child: CustomText(
                              name: AppString.appDeposit,
                              color: Appcolor.colorWhiteText,
                              fontSize: 16.sp,
                            ))),
                    Container(
                        height: 5.h,
                        width: 40.w,
                        margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.w),
                            color: Appcolor.colorToggleColor),
                        child: Center(
                            child: CustomText(
                              name: AppString.appBuy,
                              color: Appcolor.colorBlackColor,
                              fontSize: 16.sp,
                            ))),

                  ])
            ],
          ),
          // Spacer(),


        ],
      ),
    );

    // Column(
    //   children: [
    //     Container(
    //       height: 500,
    //       child:
    //       GridView.builder(
    //
    //          padding: EdgeInsets.all(20),
    //         itemCount: 6,
    //         gridDelegate:
    //             const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
    //         itemBuilder: (context, index) {
    //           return Container(
    //             margin: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
    //             color: Colors.yellow,
    //           );
    //         },
    //       ),
    //     ),
    //     Row(
    //       mainAxisAlignment: MainAxisAlignment.spaceAround,
    //       children: [
    //         Container(
    //             height: 5.h,
    //             width: 40.w,
    //             margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
    //             decoration: BoxDecoration(
    //                 borderRadius: BorderRadius.circular(10.w),
    //                 color: Appcolor.colorBlackBottomSS),
    //             child: Center(
    //                 child: CustomText(
    //               name: AppString.appDeposit,
    //               color: Appcolor.colorWhiteText,
    //               fontSize: 20.sp,
    //             ))),
    //         Padding(
    //           padding: const EdgeInsets.all(8.0),
    //           child: Container(
    //               height: 5.h,
    //               width: 40.w,
    //               margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
    //               decoration: BoxDecoration(
    //                   borderRadius: BorderRadius.circular(10.w),
    //                   color: Appcolor.colorToggleColor),
    //               child: Center(
    //                   child: CustomText(
    //                 name: AppString.appBuy,
    //                 color: Appcolor.colorBlackColor,
    //                 fontSize: 20.sp,
    //               ))),
    //         ),
    //       ],
    //     )
    //   ],
    // );
    // Column(children: [
    //   Container(height: 50.h,width: double.infinity,
    //     child: Expanded(
    //       child: GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, ), itemBuilder: (context, index) {
    //
    //         return Card(child: Container(height: 14.5.h,width: 40.w,color: Colors.yellow,));
    //
    //       },),
    //     ),
    //   ),
    //   Spacer(),
    //   Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
    //     children: [
    //       Container(
    //           height: 5.h,
    //           width: 40.w,
    //           margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
    //           decoration: BoxDecoration(
    //               borderRadius: BorderRadius.circular(10.w),
    //               color: Appcolor.colorBlackBottomSS),
    //           child: Center(
    //               child: CustomText(
    //                 name: AppString.appDeposit,
    //                 color: Appcolor.colorWhiteText,
    //                 fontSize: 20.sp,
    //               ))),
    //       Container(
    //           height: 5.h,
    //           width: 40.w,
    //           margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
    //           decoration: BoxDecoration(
    //               borderRadius: BorderRadius.circular(10.w),
    //               color: Appcolor.colorToggleColor),
    //           child: Center(
    //               child: CustomText(
    //                 name: AppString.appBuy,
    //                 color: Appcolor.colorBlackColor,
    //                 fontSize: 20.sp,
    //               ))),
    //
    //
    //     ],
    //   )
    //
    // ],
    //   // child:
    //
    // );
  }
}
