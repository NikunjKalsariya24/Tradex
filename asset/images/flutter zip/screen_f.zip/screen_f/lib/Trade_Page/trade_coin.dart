import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:screen_f/coin_list/coin_list.dart';
import 'package:screen_f/controller/trade_coin_controller.dart';

import 'package:screen_f/utils/app_colors.dart';
import 'package:screen_f/utils/app_string.dart';
import 'package:screen_f/utils/custom_text.dart';
import 'package:sizer/sizer.dart';

class TradeCoin extends StatefulWidget {
  final TabController controller;

  const TradeCoin({Key? key, required this.controller}) : super(key: key);

  @override
  State<TradeCoin> createState() => _TradeCoinState();
}

class _TradeCoinState extends State<TradeCoin> {
  final TradeCoinController tradeCoinController =
      Get.put(TradeCoinController());

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Obx(
        //   () => Row(
        //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //     children: [
        //       GestureDetector(
        //         onTap: () {
        //       tradeCoinController.coinChange.value = false;
        //           tradeCoinController.coinHot.value = true;
        //           tradeCoinController.coinMarketCap.value = false;
        //           tradeCoinController.coinPrice.value = false;
        //           //
        //           // ListView.builder(itemBuilder: (context, index) {
        //           //     return Row(children: [
        //           //
        //           //       Image.asset(CoinList.coinImages[index]),
        //           //
        //           //     ],);
        //           // },);
        //
        //           // Column( children: [
        //           //   Container(  height: 10.h,color: Colors.red,)
        //           //
        //           //
        //           // ],);
        //           const TradeHotList();
        //         },
        //         child: Container(
        //           height: 4.h,
        //           width: 15.w,
        //           decoration: BoxDecoration(
        //               color: tradeCoinController.coinHot.value
        //                   ? Appcolor.colorBlackBottomSS
        //                   : Appcolor.colorBlackColor),
        //           child: Center(
        //             child: CustomText(
        //                 name: AppString.appCoinHot,
        //                 fontSize: 12.sp,
        //                 color: Appcolor.colorWhiteText),
        //           ),
        //         ),
        //       ),
        //       GestureDetector(
        //         onTap: () {
        //           tradeCoinController.coinChange.value = false;
        //           tradeCoinController.coinHot.value = false;
        //           tradeCoinController.coinMarketCap.value = true;
        //           tradeCoinController.coinPrice.value = false;
        //         },
        //         child: Container(
        //           height: 4.h,
        //           width: 30.w,
        //           decoration: BoxDecoration(
        //               color: tradeCoinController.coinMarketCap.value
        //                   ? Appcolor.colorBlackBottomSS
        //                   : Appcolor.colorBlackColor),
        //           child: Center(
        //             child: CustomText(
        //                 name: AppString.appCoinMarketCap,
        //                 fontSize: 12.sp,
        //                 color: Appcolor.colorWhiteText),
        //           ),
        //         ),
        //       ),
        //       GestureDetector(
        //         onTap: () {
        //           tradeCoinController.coinChange.value = false;
        //           tradeCoinController.coinHot.value = false;
        //           tradeCoinController.coinMarketCap.value = false;
        //           tradeCoinController.coinPrice.value = true;
        //         },
        //         child: Container(
        //           height: 4.h,
        //           decoration: BoxDecoration(
        //               color: tradeCoinController.coinPrice.value
        //                   ? Appcolor.colorBlackBottomSS
        //                   : Appcolor.colorBlackColor),
        //           child: Row(
        //             children: [
        //               Center(
        //                 child: CustomText(
        //                     name: AppString.appCoinPrice,
        //                     fontSize: 12.sp,
        //                     color: Appcolor.colorWhiteText),
        //               ),
        //               Padding(
        //                 padding: EdgeInsets.symmetric(horizontal: 2.w),
        //                 child: Image.asset(
        //                   ImageAssets.arro,
        //                   height: 2.h,
        //                 ),
        //               ),
        //             ],
        //           ),
        //         ),
        //       ),
        //       GestureDetector(
        //         onTap: () {
        //           tradeCoinController.coinChange.value = true;
        //           tradeCoinController.coinHot.value = false;
        //           tradeCoinController.coinMarketCap.value = false;
        //           tradeCoinController.coinPrice.value = false;
        //         },
        //         child: Container(
        //           height: 4.h,
        //           width: 30.w,
        //           decoration: BoxDecoration(
        //               color: tradeCoinController.coinChange.value
        //                   ? Appcolor.colorBlackBottomSS
        //                   : Appcolor.colorBlackColor),
        //           child: Center(
        //             child: Row(
        //               children: [
        //                 CustomText(
        //                     name: AppString.appChange,
        //                     fontSize: 12.sp,
        //                     color: Appcolor.colorWhiteText),
        //                 Padding(
        //                   padding: EdgeInsets.symmetric(horizontal: 2.w),
        //                   child: Image.asset(
        //                     ImageAssets.arro,
        //                     height: 2.h,
        //                   ),
        //                 ),
        //               ],
        //             ),
        //           ),
        //         ),
        //       ),
        //     ],
        //   ),
        // ),
        // Obx(() =>    ListView.builder(itemBuilder: (context, index) {
        //      return Row(children: [
        //
        //
        //
        //      ],);
        //    },)
        // )

        _coinTabCustomWidget(),
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 3.w),
            child: ListView.builder(
              itemCount: CoinList.coinImages.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 1.w, vertical: 1.h),
                  child: Row(
                    children: [
                      // Container(height: 8.h,margin: EdgeInsets.only(left: 3.w),child: Center(child:
                      Align(
                        alignment: Alignment.center,
                        child: Image.asset(
                          CoinList.coinImages[index],
                          fit: BoxFit.fill,
                        ),
                      ),
                      // )),
                      const Spacer(),
                      //   SizedBox(width: 5.w,),

                      Column(
                        children: [
                          CustomText(
                              name: CoinList.coinName[index],
                              fontSize: 18.sp,
                              color: Appcolor.colorWhiteText),
                          CustomText(
                              name: CoinList.coinFullName[index],
                              fontSize: 12.sp,
                              color: Appcolor.colorWhiteText),
                        ],
                      ),
                      const Spacer(),
                      Image.asset(CoinList.coinGraph[index]),
                      const Spacer(),
                      Column(
                        children: [
                          CustomText(
                              name: CoinList.coinValue[index],
                              fontSize: 18.sp,
                              color: Appcolor.colorWhiteText),
                          CustomText(
                              name: CoinList.coinValueDifferance[index],
                              fontSize: 12.sp,
                              color: Appcolor.colorWhiteText),
                        ],
                      )
                    ],
                  ),
                );
              },
            ),
          ),
        ),

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 5.h,
              color: Colors.yellow,
            ),
            Container(
              height: 5.h,
              color: Colors.yellow,
            ),
          ],
        ),

        Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Container(
                height: 5.h,
                width: 40.w,
                margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.w),
                    color: Appcolor.colorBlackBottomSS),
                child: Center(
                    child: CustomText(
                      name: AppString.appDeposit,
                      color: Appcolor.colorWhiteText,
                      fontSize: 20.sp,
                    ))),
            Container(
                height: 5.h,
                width: 40.w,
                margin: EdgeInsets.only(left: 1.w, bottom: 1.h),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.w),
                    color: Appcolor.colorToggleColor),
                child: Center(
                    child: CustomText(
                  name: AppString.appBuy,
                  color: Appcolor.colorBlackColor,
                  fontSize: 20.sp,
                ))),


          ],
        )
      ],
    );
  }

  _coinTabCustomWidget() {
    //
    // return Container(height: 6.h,
    // child: ListView.builder(itemBuilder: itemBuilder),)
    // return Container(
    //   height: 6.h,
    //   width: double.infinity,
    //   color: Colors.yellow,
    //     child:
    //     ListView.builder(itemBuilder: (context, index) {
    //       return Obx(() =>Row(children: [
    //         Container(height: 3.h,child: tradeCoinController.customTabBarList[index],)
    //
    //
    //       ],),);
    //     },
    //),

    // );

    return Container(
      margin: EdgeInsets.only(left: 3.w),
      width: double.infinity,
      height: 4.h,
      child: ListView.builder(
          padding: EdgeInsets.zero,
          physics: const BouncingScrollPhysics(),
          itemCount: tradeCoinController.customTabBarList.length,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return Obx(() => Column(
                  children: [
                    GestureDetector(
                      onTap: () {
                        tradeCoinController.currentValue.value = index;
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        decoration: BoxDecoration(
                            color:
                                tradeCoinController.currentValue.value == index
                                    ? Appcolor.colorBlackBottomSS
                                    : Colors.black,
                            borderRadius: BorderRadius.circular(2.w)),
                        margin:
                            EdgeInsets.only(left: 3.w, right: 3.w, top: 1.w),
                        padding: EdgeInsets.symmetric(horizontal: 2.w),
                        height: 3.h,
                        child: Center(
                          child: tradeCoinController.customTabBarList[index],
                        ),
                      ),
                    ),
                  ],
                ));
          }),
    );
    // return Container(height: 4.h,width: double.infinity,child: ListView.builder(physics: const BouncingScrollPhysics(),
    //     itemCount: tradeCoinController.customTabBarList.length,scrollDirection: Axis.horizontal,itemBuilder: (context, index) {
    //
    //   return Obx(() => Column(
    //     children: [
    //       GestureDetector(onTap: () {
    //         tradeCoinController.currentValue.value=index;
    //
    //       },child: AnimatedContainer(duration: Duration( milliseconds: 300,
    //
    //       ),
    //       height: 3.h,
    //       child: tradeCoinController.customTabBarList[index]),)
    //     ],
    //   ));
    // },),);
    //
    //
    //
  }
}
