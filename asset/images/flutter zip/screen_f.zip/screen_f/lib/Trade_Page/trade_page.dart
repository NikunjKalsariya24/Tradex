import 'package:flutter/material.dart';
import 'package:screen_f/Trade_Page/trade_grid.dart';
import 'package:screen_f/Trade_Page/trade_homepage.dart';
import 'package:screen_f/Trade_Page/trade_vector.dart';
import 'package:screen_f/Trade_Page/trade_wallet.dart';
import 'package:screen_f/utils/app_assets.dart';
import 'package:screen_f/utils/app_colors.dart';
import 'package:screen_f/utils/app_string.dart';
import 'package:screen_f/utils/custom_text.dart';
import 'package:sizer/sizer.dart';

class TradePage extends StatefulWidget {
  const TradePage({Key? key}) : super(key: key);

  @override
  State<TradePage> createState() => _TradePageState();
}

class _TradePageState extends State<TradePage> {
  int currentNavigationTab = 0;

  final List<Widget> screen = [
    const TradeHomePage(),
    const TradeVectorScreen(),
    const TradeWalletScreen(),
    const TradeGridScreen(),
  ];

  final PageStorageBucket bucket = PageStorageBucket();

  Widget currentScreen = const TradeHomePage();

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Scaffold(
          // backgroundColor: Appcolor.colorBlackColor,
          body: PageStorage(bucket: bucket, child: currentScreen),
          // floatingActionButton: FloatingActionButton(
          //   backgroundColor: Appcolor.colorToggleColor,
          //   onPressed: () {
          //     // showModalBottomSheet(isScrollControlled: true,
          //     //   useRootNavigator: true,
          //     //   context: context,
          //     //   builder: (context) {
          //     //           return Container(
          //     //
          //     //             height: 20.h,
          //     //             width: double.infinity,
          //     //             color: Appcolor.colorBlackBottomSS,
          //     //             child: Padding(padding: EdgeInsets.symmetric(horizontal: 7.w,vertical: 4.w),
          //     //
          //     //             child: Column(
          //     //               children: [
          //     //
          //     //                 Row(mainAxisAlignment: MainAxisAlignment.start,children: [
          //     //                     Container( child: CustomText(name: "Buy Now", fontSize: 20.sp),)
          //     //
          //     //                 ],),
          //     //
          //     //                 Row(mainAxisAlignment: MainAxisAlignment.start,children: [
          //     //                   Container( child: CustomText(name: "Deposit", fontSize: 20.sp),)
          //     //
          //     //                 ],),
          //     //               ],
          //     //
          //     //
          //     //             )),
          //     //
          //     //           );
          //     //
          //     //   },);
          //   },
          //   child: Image.asset(ImageAssets.tradeArrowImagePath),
          // ),
          // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
          bottomNavigationBar: BottomAppBar(
            shape: const CircularNotchedRectangle(),
            notchMargin: 10,
            child: Container(
              height: 8.h,
              decoration:
                  const BoxDecoration(color: Appcolor.colorBlackGradiant),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // MaterialButton(minWidth:10.w,onPressed: () {
                      //   setState(() {
                      //     currentScreen=const TradeHomePage();
                      //     currentNavigationTab=0;
                      //   });
                      //
                      // },
                      //   child:
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              currentScreen = const TradeHomePage();
                              currentNavigationTab = 0;
                            });
                          },
                          child: SizedBox(
                              height: 10.h,
                              width: 20.w,
                              child: Image.asset(
                                ImageAssets.tradeHomeImagePath,
                                color: currentNavigationTab == 0
                                    ? Appcolor.colorToggleColor
                                    : Appcolor.colorWhiteText,
                              ))),

                      // ),
                      // MaterialButton(minWidth:5.h,onPressed: () {
                      //   setState(() {
                      //     currentScreen=const TradeVectorScreen();
                      //     currentNavigationTab=1;
                      //   });
                      //
                      // },
                      //   child:
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              currentScreen = const TradeVectorScreen();
                              currentNavigationTab = 1;
                            });
                          },
                          child: SizedBox(
                              height: 10.h,
                              width: 20.w,
                              child: Image.asset(
                                ImageAssets.tradeVectorImagePath,
                                color: currentNavigationTab == 1
                                    ? Appcolor.colorToggleColor
                                    : Appcolor.colorWhiteText,
                              ))),

                      // ),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      //
                      // MaterialButton(minWidth:30.w,onPressed: () {
                      //   setState(() {
                      //     currentScreen=const TradeWalletScreen();
                      //     currentNavigationTab=2;
                      //   });
                      //
                      // },
                      //   child:

                      GestureDetector(
                        onTap: () {
                          setState(() {
                            currentScreen = const TradeWalletScreen();
                            currentNavigationTab = 2;
                          });
                        },
                        child: SizedBox(
                            height: 10.h,
                            width: 20.w,
                            child: Image.asset(
                              ImageAssets.tradeWalletImagePath,
                              color: currentNavigationTab == 2
                                  ? Appcolor.colorToggleColor
                                  : Appcolor.colorWhiteText,
                            )),
                      ),

                      // ),
                      // MaterialButton(minWidth:10.w,onPressed: () {
                      //   setState(() {
                      //     currentScreen=const TradeGridScreen();
                      //     currentNavigationTab=3;
                      //   });
                      //
                      // },
                      //   child:
                      GestureDetector(
                          onTap: () {
                            setState(() {
                              currentScreen = const TradeGridScreen();
                              currentNavigationTab = 3;
                            });
                          },
                          child: SizedBox(
                              height: 10.h,
                              width: 20.w,
                              child: Image.asset(
                                ImageAssets.tradeGridImagePath,
                                color: currentNavigationTab == 3
                                    ? Appcolor.colorToggleColor
                                    : Appcolor.colorWhiteText,
                              ))),

                      // ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: GestureDetector(
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  builder: (context) {
                    return Container(
                      height: 30.h,
                      width: double.infinity,
                      decoration:
                          const BoxDecoration(color: Appcolor.colorBlackGradiant),
                      child: Column(children: [
                        Padding(
                          padding: EdgeInsets.fromLTRB(6.w, 1.h, 1.h, 0),
                          child: Row(
                            children: [
                              Container(
                                  height: 8.h,
                                  width: 8.w,
                                  decoration: const BoxDecoration(
                                      color: Appcolor.colorToggleColor,
                                      shape: BoxShape.circle),
                                  child: const Icon(
                                    Icons.add,
                                    color: Appcolor.colorBlackColor,
                                  )),
                              Column(children: [
                                CustomText(
                                  textAlign: TextAlign.start,
                                  name: AppString.appBuy,
                                  fontSize: 20.sp,
                                  color: Appcolor.colorWhiteText,
                                ),
                                CustomText(
                                  textAlign: TextAlign.start,
                                  name: AppString.appBuyBtc,
                                  fontSize: 10.sp,
                                  color: Appcolor.colorWhiteText,
                                )
                              ])
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(6.w, 1.h, 1.h, 0),
                          child: Row(
                            children: [
                              Container(
                                  height: 8.h,
                                  width: 8.w,
                                  decoration: const BoxDecoration(
                                      color: Appcolor.colorToggleColor,
                                      shape: BoxShape.circle),
                                  child: const Icon(
                                    Icons.add,
                                    color: Appcolor.colorBlackColor,
                                  )),
                              Column(children: [
                                CustomText(
                                  textAlign: TextAlign.start,
                                  name: AppString.appBuy,
                                  fontSize: 20.sp,
                                  color: Appcolor.colorWhiteText,
                                ),
                                CustomText(
                                  textAlign: TextAlign.start,
                                  name: AppString.appBuyBtc,
                                  fontSize: 10.sp,
                                  color: Appcolor.colorWhiteText,
                                )
                              ])
                            ],
                          ),
                        ),
                        Align(alignment: Alignment.bottomCenter,child: Container(height: 5.h,width: 5.w,decoration: const BoxDecoration(color: Appcolor.colorToggleColor,shape: BoxShape.circle),child: const Icon(Icons.close,color: Appcolor.colorWhiteText,))),
                      ]),
                    );
                  },
                );
              },
              child: Container(
                  height: 8.h,
                  decoration: const BoxDecoration(
                      color: Appcolor.colorToggleColor, shape: BoxShape.circle),
                  child: Image.asset(ImageAssets.tradeArrowImagePath))),
        )
      ],
    );
  }
}
