import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:screen_f/Trade_Page/tab_bar.dart';
import 'package:screen_f/coin_list/coin_list.dart';
import 'package:screen_f/controller/trade_coin_controller.dart';
import 'package:screen_f/utils/app_colors.dart';
import 'package:screen_f/utils/app_string.dart';
import 'package:screen_f/utils/custom_text.dart';
import 'package:sizer/sizer.dart';
import 'package:toggle_switch/toggle_switch.dart';

class TradeVectorScreen extends StatefulWidget {
  const TradeVectorScreen({Key? key}) : super(key: key);

  @override
  State<TradeVectorScreen> createState() => _TradeVectorScreenState();
}

class _TradeVectorScreenState extends State<TradeVectorScreen>
    with TickerProviderStateMixin {
  final TradeCoinController tradeCoinController =
      Get.put(TradeCoinController());
  RxInt toggleIndexValue = 0.obs;

  @override
  Widget build(BuildContext context) {
    TabController tabCController = TabController(length: 4, vsync: this);
    return Scaffold(
        backgroundColor: Appcolor.colorBlackColor,
        body: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 3.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    alignment: Alignment.topLeft,
                    height: 8.h,
                    margin: EdgeInsets.only(left: 1.w),
                    child: CustomText(
                      name: AppString.appTrad,
                      fontFamily: AppString.fontFamily,
                      fontSize: 30.sp,
                      color: Appcolor.colorWhiteText,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    margin: EdgeInsets.only(
                      left: 30.w,
                    ),
                    child: Icon(Icons.search,
                        color: Appcolor.colorWhiteText, size: 8.w),
                  ),
                  Icon(Icons.person, color: Appcolor.colorWhiteText, size: 8.w)
                ],
              ),
            ),
            Container(
              height: 5.h,
              width: double.infinity,
              margin: EdgeInsets.only(left: 0.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3.w),
                border:
                    Border.all(width: 0, color: Appcolor.colorBlackGradiant),
              ),
              child: ToggleSwitch(
                initialLabelIndex: 0,
                totalSwitches: 3,
                fontSize: 12.sp,
                minHeight: 5.h,
                customWidths: [33.w, 33.w, 33.w],
                minWidth: double.infinity,
                activeBgColor: const [Appcolor.colorBlackGradiant],
                activeFgColor: Appcolor.colorWhiteText,
                inactiveBgColor: Appcolor.colorBlackColor,
                inactiveFgColor: Appcolor.colorYellowFull,
                labels: const [
                  AppString.cryptoToggle,
                  AppString.stokes,
                  AppString.forex
                ],
                onToggle: (index) {
                  if (kDebugMode) {
                    print('switched to: $index');
                  }
                  toggleIndexValue.value = index ?? 0;
                },
              ),
            ),

            Container(
              height: 3.h,
              width: double.infinity,
              margin: EdgeInsets.only(top: 1.h),
              child: TabBar(
                  controller: tabCController,
                  labelPadding: EdgeInsets.symmetric(horizontal: 3.w),
                  isScrollable: false,
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicator: BoxDecoration(
                      color: Appcolor.colorBlackGradiant,
                      borderRadius: BorderRadius.circular(1.w)),
                  tabs: [
                    CustomTabBar(name: AppString.allAssets, fontSize: 8.sp),
                    CustomTabBar(name: AppString.favorites, fontSize: 8.sp),
                    CustomTabBar(name: AppString.price, fontSize: 8.sp),
                    CustomTabBar(name: AppString.appChange, fontSize: 8.sp),
                  ]),
            ),

            Obx(() => toggleIndexValue.value == 0
                ? _cryptoTab()
                : toggleIndexValue.value == 1
                    ? _stokeTab()
                    : _forex()),
            // _vectorTabCustomWidget(),
          ],
        ));
  }

  _cryptoTab() {
    return Expanded(
      child: ListView.builder(
        itemCount: CoinList.allAssets.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 4.h),
            child: Row(children: [
              Align(
                alignment: Alignment.center,
                child: Image.asset(
                  CoinList.coinBtcImages[index],
                  fit: BoxFit.fill,
                ),
              ),
              const Spacer(),
              Column(
                children: [
                  CustomText(
                      name: CoinList.allAssets[index].coinName,
                      color: Appcolor.colorWhiteText,
                      fontSize: 14.sp),
                  CustomText(
                      name: CoinList.allAssets[index].coinFName,
                      color: Appcolor.colorYellowFull,
                      fontSize: 12.sp),
                ],
              ),
              const Spacer(),
              Image.asset(CoinList.btcCoinGraph[index], fit: BoxFit.fill),
              const Spacer(),
              Column(
                children: [
                  CustomText(
                      name: CoinList.allAssets[index].coinBitCoinPrice,
                      color: Appcolor.colorWhiteText,
                      fontSize: 14.sp),
                  CustomText(
                      name: CoinList.allAssets[index].coinDifferance,
                      color: index == 5 || index == 6
                          ? Appcolor.colorListDown
                          : Appcolor.colorList,
                      fontSize: 14.sp),
                ],
              ),
            ]),
          );
        },
      ),
    );
  }

  _stokeTab() {
    return Expanded(
        child: Container(
      color: Appcolor.colorBlackColor,
    ));
  }

  _forex() {
    return Expanded(
        child: Container(
      color: Appcolor.colorBlackColor,
    ));
  }

// _vectorTabCustomWidget() {
// return Container(
//   margin: EdgeInsets.only(left: 3.w),
//   width: double.infinity,
//   height: 4.h,
//   child: ListView.builder(
//     itemCount: tradeCoinController.customVectorTabBar.length,
//     scrollDirection: Axis.horizontal,
//     itemBuilder: (context, index) {
//       return Obx(() => Column(
//             children: [
//               GestureDetector(
//                 onTap: () {
//                   tradeCoinController.vectorCurrentValue.value = index;
//                 },
//                 child: AnimatedContainer(
//                   duration: const Duration(milliseconds: 300),
//                   decoration: BoxDecoration(
//                     color: tradeCoinController.vectorCurrentValue.value ==
//                             index
//                         ? Appcolor.colorBlackBottomSS
//                         : Appcolor.colorBlackColor,
//                     borderRadius: BorderRadius.all(
//                       Radius.elliptical(1.h, 1.w),
//                     ),
//                   ),margin:
//                 EdgeInsets.only(left: 3.w, right: 3.w, top: 1.w),
//                   padding: EdgeInsets.symmetric(horizontal: 2.w),
//                   height: 3.h,
//                   child:Center(child: tradeCoinController.customVectorTabBar[index],),
//                 ),
//               ),
//             ],
//           ));
//     },
//   ),
// );

// Here, default theme colors are used for activeBgColor, activeFgColor, inactiveBgColor and inactiveFgColor
// return ToggleSwitch(
//   initialLabelIndex: 0,
//   totalSwitches: 3,
//   fontSize: 12.sp,
//   minHeight: 5.h,
//   minWidth: double.infinity,
//   activeBgColor: const [Appcolor.colorBlackGradiant],
//   activeFgColor: Appcolor.colorWhiteText,
//   inactiveBgColor: Appcolor.colorBlackColor,
//   inactiveFgColor: Appcolor.colorYellowFull,
//   labels: const [AppString.cryptoToggle, AppString.stokes, AppString.forex],
//   onToggle: (index) {
//     if (kDebugMode) {
//       print('switched to: $index');
//     }
//   },
// );
// }
}
