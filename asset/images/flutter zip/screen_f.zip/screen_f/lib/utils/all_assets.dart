class AllAssets
{

  String ?coinFName;
  String ?coinName;
  String ?coinPrice;
  String ?coinBitCoinPrice;
  String ?coinDifferance;


  AllAssets(
      {this.coinFName,
      this.coinName,
      this.coinPrice,
      this.coinDifferance,
      this.coinBitCoinPrice});
}