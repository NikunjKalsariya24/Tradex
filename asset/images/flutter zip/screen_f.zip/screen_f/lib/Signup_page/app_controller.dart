import 'package:flutter/cupertino.dart';

class AppController
{


        static TextEditingController textFieldName=TextEditingController();
        static TextEditingController textFieldCountry=TextEditingController();
        static TextEditingController textFieldNumber=TextEditingController();

        static TextEditingController textFieldADDarCardNumber=TextEditingController();
        static TextEditingController textFieldEmail=TextEditingController();
        static TextEditingController textFieldPassword=TextEditingController();
        static TextEditingController textFieldReEnterPassword=TextEditingController();

}